module.exports = {
	dist: [
		'<%= config.dist.root %>'
	],
	vendor: [
		'<%= config.src.vendor %>'
	],
	bower: [
		'bower_components'
	]
};
