module.exports = {
	dev: {
		options: {
			title: 'Grunt',
			message: 'Development process started'
		}
	}
};