module.exports = {
	bowerinstall: {
		command: 'bower install'
	}
};
