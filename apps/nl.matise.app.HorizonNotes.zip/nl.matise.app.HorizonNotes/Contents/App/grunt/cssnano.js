module.exports = {
  options: {
    sourcemap: false
  },
  dist: {
    files: {
      'dist/css/app.css': 'dist/css/app.css'
    }
  }
};
