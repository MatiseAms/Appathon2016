# Horizon Notes
Horizon Notes Angular

start new project on this branch run:
* npm install
* grunt bowerinit

To work on this project in this branch run: grunt
