angular.module('notes')
	.controller('TopController', [function() {
		'use strict';

		var self = this;
		self.hello = 'hello';

	}]);
