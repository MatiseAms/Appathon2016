angular.module('notes')
	.controller('HomeController', [function() {
		'use strict';

		var self = this;
		self.hello = 'hello';

	}]);
