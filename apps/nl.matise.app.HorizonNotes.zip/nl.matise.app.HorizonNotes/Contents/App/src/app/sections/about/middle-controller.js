angular.module('notes')
	.controller('MiddleController', [function() {
		'use strict';

		var self = this;
		self.hello = 'hello';

	}]);
