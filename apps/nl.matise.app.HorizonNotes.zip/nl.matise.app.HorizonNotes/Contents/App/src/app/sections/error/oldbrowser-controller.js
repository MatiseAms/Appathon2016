angular.module('notes')
	.controller('OldBrowserController', [function() {
		'use strict';

		var self = this;
		self.hello = 'hello';

	}]);
