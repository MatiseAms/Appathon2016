angular.module('notes')
	.controller('AboutController', [function() {
		'use strict';

		var self = this;
		self.hello = 'hello';

	}]);
