angular.module('notes')
	.controller('BottomController', [function() {
		'use strict';

		var self = this;
		self.hello = 'hello';

	}]);
