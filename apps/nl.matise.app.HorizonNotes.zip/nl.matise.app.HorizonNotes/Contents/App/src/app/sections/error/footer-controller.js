angular.module('notes')
	.controller('FooterController', [function() {
		'use strict';

		var self = this;
		self.hello = 'hello';

	}]);
