angular.module('notes')
	.controller('HeaderController', [function() {
		'use strict';

		var self = this;
		self.hello = 'hello';

	}]);
